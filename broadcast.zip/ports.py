# ports.py

broadcast = 10000
server = 10001
